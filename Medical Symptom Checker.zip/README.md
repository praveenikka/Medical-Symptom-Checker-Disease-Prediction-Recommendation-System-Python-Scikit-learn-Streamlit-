# Medical Symptom Checker: Classification, Prediction, and Recommendation System

Beginner-friendly ML project using pandas, numpy, scikit-learn, matplotlib, seaborn, and Streamlit. It predicts likely diseases from symptoms and demographics, ranks top possibilities, and suggests next steps.

## Project Structure

- data/
  - raw/ — original dataset (symptoms.csv)
  - processed/ — processed parquet
- models/ — saved models and encoders
- reports/
  - figures/ — EDA charts
- src/
  - data_prep.py — cleaning, preprocessing, feature engineering
  - train.py — model training and evaluation
  - predict.py — single-sample prediction utilities
  - recommender.py — simple rule-based guidance
  - eda.py — exploratory data analysis and plots
- app.py — Streamlit UI
- requirements.txt

## Dataset
Your dataset has been copied to:
- data/raw/symptoms.csv

Expected columns (inferred from your file):
- Patient ID, Age, Gender, Symptoms, Predicted Disease, Severity, Confidence Score (%)

Notes:
- "Symptoms" is a comma-separated list like: "Fever, Cough, Fatigue".
- The label used for training is "Predicted Disease".

## Quickstart (Windows, PowerShell)

1) Create and activate a virtual environment

```powershell path=null start=null
python -m venv .venv
. .venv\Scripts\Activate.ps1
```

2) Install dependencies

```powershell path=null start=null
pip install -r requirements.txt
```

3) Prepare data (clean, encode, save artifacts)

```powershell path=null start=null
python src/data_prep.py
```

4) Train models and evaluate

```powershell path=null start=null
python src/train.py
```

5) Launch the Streamlit app

```powershell path=null start=null
streamlit run app.py
```

## What This App Does
- Classification: Predicts the most likely disease from selected symptoms + age + gender.
- Ranked Predictions: Shows top-3 possible diseases with probability scores.
- Recommendations: Provides next steps (self-care, tests, specialist) depending on confidence.

## Evaluation Metrics
- Accuracy, Precision, Recall, F1-score (macro)
- Top-3 probabilities for ranked output

## Customization Tips
- Update rule mappings in src/recommender.py to tailor actions per disease.
- Add/remove models in src/train.py to compare performance.
- Modify EDA in src/eda.py to explore more insights.

## Disclaimer
This project is for educational purposes. It is not a substitute for professional medical advice, diagnosis, or treatment.
