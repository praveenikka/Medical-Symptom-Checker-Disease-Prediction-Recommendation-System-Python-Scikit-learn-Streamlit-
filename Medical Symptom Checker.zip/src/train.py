import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report
from sklearn.model_selection import train_test_split

# Paths
ROOT = Path(__file__).resolve().parents[1]
PROCESSED_PATH = ROOT / "data" / "processed" / "dataset.parquet"
ARTIFACTS_DIR = ROOT / "models"
FEATURE_COLUMNS_PATH = ARTIFACTS_DIR / "feature_columns.json"
LABEL_ENCODER_PATH = ARTIFACTS_DIR / "label_encoder.joblib"
BEST_MODEL_PATH = ARTIFACTS_DIR / "best_model.joblib"
METRICS_PATH = ROOT / "reports" / "metrics.json"


def load_processed():
    df = pd.read_parquet(PROCESSED_PATH)
    with open(FEATURE_COLUMNS_PATH, "r", encoding="utf-8") as f:
        feature_columns = json.load(f)
    X = df[feature_columns]
    y = df["label"].astype(int)
    return X, y


def evaluate(y_true, y_pred):
    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_macro": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "classification_report": classification_report(y_true, y_pred, output_dict=True, zero_division=0),
    }
    return metrics


def main():
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)

    X, y = load_processed()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Two simple baseline models
    models = {
        "RandomForest": RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced"),
        "LogReg_OvR": LogisticRegression(max_iter=1000, multi_class="ovr", solver="liblinear")
    }

    results = {}
    best_name = None
    best_f1 = -1.0
    best_model = None

    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        m = evaluate(y_test, y_pred)
        results[name] = m
        if m["f1_macro"] > best_f1:
            best_f1 = m["f1_macro"]
            best_name = name
            best_model = model

    # Save best model
    joblib.dump(best_model, BEST_MODEL_PATH)

    # Save metrics
    with open(METRICS_PATH, "w", encoding="utf-8") as f:
        json.dump({"best_model": best_name, "results": results}, f, indent=2)

    print("Training complete:")
    print(f"- Best model: {best_name}")
    print(f"- Saved to: {BEST_MODEL_PATH}")
    print(f"- Metrics: {METRICS_PATH}")


if __name__ == "__main__":
    main()
