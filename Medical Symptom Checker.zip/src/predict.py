from pathlib import Path
import json
from typing import List, Dict, Tuple

import joblib
import numpy as np
import pandas as pd

# Paths
ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS_DIR = ROOT / "models"
BEST_MODEL_PATH = ARTIFACTS_DIR / "best_model.joblib"
FEATURE_COLUMNS_PATH = ARTIFACTS_DIR / "feature_columns.json"
SYMPTOM_VOCAB_PATH = ARTIFACTS_DIR / "symptom_vocab.json"
LABEL_ENCODER_PATH = ARTIFACTS_DIR / "label_encoder.joblib"

AGE_COL = "Age"


def _load_artifacts():
    model = joblib.load(BEST_MODEL_PATH)
    with open(FEATURE_COLUMNS_PATH, "r", encoding="utf-8") as f:
        feature_columns = json.load(f)
    with open(SYMPTOM_VOCAB_PATH, "r", encoding="utf-8") as f:
        symptom_vocab = json.load(f)
    le = joblib.load(LABEL_ENCODER_PATH)
    return model, feature_columns, symptom_vocab, le


def _vectorize_input(age: int, gender: str, chosen_symptoms: List[str], feature_columns: List[str], symptom_vocab: List[str]) -> pd.DataFrame:
    # Build a single-row feature dict initialized with zeros
    features = {col: 0 for col in feature_columns}
    # Age
    features[AGE_COL] = age
    # Gender column names: e.g., gender_Female, gender_Male, gender_Unknown
    gcol = f"gender_{str(gender).title()}"
    if gcol in features:
        features[gcol] = 1
    else:
        # If an unseen gender category, map to gender_Unknown when present
        if "gender_Unknown" in features:
            features["gender_Unknown"] = 1

    # Symptoms: normalize like in data_prep
    chosen = [s.strip().lower() for s in chosen_symptoms]
    # Use the same naming as data_prep: symptom_{token with spaces replaced}
    for tok in chosen:
        col_name = f"symptom_{tok.replace(' ', '_')}"
        if col_name in features:
            features[col_name] = 1

    X = pd.DataFrame([features], columns=feature_columns)
    return X


def predict(age: int, gender: str, symptoms: List[str], top_k: int = 3) -> Tuple[str, List[Tuple[str, float]]]:
    model, feature_columns, symptom_vocab, le = _load_artifacts()
    X = _vectorize_input(age, gender, symptoms, feature_columns, symptom_vocab)

    # Probas for multi-class
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X)[0]
    else:
        # Fallback: use decision_function and softmax-like scaling
        dec = model.decision_function(X)
        if dec.ndim == 1:
            # binary case
            probs = np.vstack([1 - dec, dec])[0]
        else:
            exp = np.exp(dec - dec.max())
            probs = (exp / exp.sum(axis=1, keepdims=True))[0]

    top_idx = np.argsort(probs)[::-1][:top_k]
    top = [(le.inverse_transform([i])[0], float(probs[i])) for i in top_idx]

    # Predicted label
    pred_idx = int(top_idx[0])
    pred_label = le.inverse_transform([pred_idx])[0]

    return pred_label, top


if __name__ == "__main__":
    # Example manual test
    label, ranked = predict(age=30, gender="Female", symptoms=["Fever", "Cough", "Fatigue"], top_k=3)
    print("Prediction:", label)
    print("Top-3:")
    for name, p in ranked:
        print(f"- {name}: {p:.2f}")
