import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
RAW_DATA_PATH = ROOT / "data" / "raw" / "symptoms.csv"
FIG_DIR = ROOT / "reports" / "figures"


def main():
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RAW_DATA_PATH)

    # Basic disease counts
    plt.figure(figsize=(8, 4))
    ax = sns.countplot(data=df, y="Predicted Disease", order=df["Predicted Disease"].value_counts().index)
    ax.set_title("Disease Counts")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "disease_counts.png", dpi=150)
    plt.close()

    # Gender distribution per disease (top 10 diseases)
    top10 = df["Predicted Disease"].value_counts().head(10).index
    sub = df[df["Predicted Disease"].isin(top10)]
    plt.figure(figsize=(10, 5))
    sns.countplot(data=sub, x="Predicted Disease", hue="Gender")
    plt.title("Gender Distribution (Top 10 Diseases)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "gender_by_disease.png", dpi=150)
    plt.close()

    # Symptom frequency (top 20)
    def explode_symptoms(s):
        if pd.isna(s) or not str(s).strip():
            return []
        return [t.strip().title() for t in str(s).split(",") if t.strip()]

    symptoms = []
    for cell in df["Symptoms"].fillna(""):
        symptoms.extend(explode_symptoms(cell))
    symp_counts = pd.Series(symptoms).value_counts().head(20)

    plt.figure(figsize=(8, 5))
    sns.barplot(x=symp_counts.values, y=symp_counts.index, orient="h")
    plt.title("Top 20 Symptoms")
    plt.xlabel("Count")
    plt.tight_layout()
    plt.savefig(FIG_DIR / "top_symptoms.png", dpi=150)
    plt.close()

    print(f"Saved figures to {FIG_DIR}")


if __name__ == "__main__":
    main()
