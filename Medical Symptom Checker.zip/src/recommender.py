from typing import List, Tuple

# Simple rule-based recommender
# You can customize/expand these rules to fit your needs.

DISEASE_TO_GUIDANCE = {
    "Influenza": {
        "specialist": "General Physician",
        "tests": ["Rapid flu test (if available)", "CBC"],
        "self_care": ["Rest", "Hydration", "Paracetamol for fever"],
    },
    "Common Cold": {
        "specialist": "General Physician",
        "tests": ["None typically required"],
        "self_care": ["Rest", "Fluids", "Steam inhalation"],
    },
    "Migraine": {
        "specialist": "Neurologist",
        "tests": ["Clinical evaluation"],
        "self_care": ["Dark room rest", "Hydration"],
    },
    "Food Poisoning": {
        "specialist": "General Physician / Gastroenterologist",
        "tests": ["Stool test (if severe/prolonged)", "CBC"],
        "self_care": ["ORS", "Light diet", "Avoid dairy"],
    },
    "Heart Attack": {
        "specialist": "Cardiologist (Emergency)",
        "tests": ["ECG", "Troponin", "Chest X-ray"],
        "self_care": ["Seek emergency care immediately"],
    },
}


SEVERITY_THRESHOLDS = {
    # Cutoffs based on top predicted probability
    "critical": 0.80,
    "elevated": 0.60,
}


def recommend(top_predictions: List[Tuple[str, float]], age: int, gender: str) -> List[str]:
    """
    Produce a simple ranked recommendation list given top predictions.
    """
    actions = []
    top_label, top_prob = top_predictions[0]

    guidance = DISEASE_TO_GUIDANCE.get(top_label, {
        "specialist": "General Physician",
        "tests": ["Clinical evaluation"],
        "self_care": ["Rest", "Hydration"],
    })

    if top_label == "Heart Attack":
        actions.append("EMERGENCY: Call emergency services or go to the nearest ER immediately.")
        actions.append("Do not delay seeking care.")
        return actions

    if top_prob >= SEVERITY_THRESHOLDS["critical"]:
        actions.append(f"High confidence of {top_label}. Book an appointment with a {guidance['specialist']} soon (within 24 hours).")
        actions.append(f"Recommended tests: {', '.join(guidance['tests'])}.")
        actions.append(f"Self-care: {', '.join(guidance['self_care'])}.")
    elif top_prob >= SEVERITY_THRESHOLDS["elevated"]:
        actions.append(f"Possible {top_label}. Consider seeing a {guidance['specialist']} within 48 hours if symptoms persist.")
        actions.append(f"Suggested tests (if symptoms worsen): {', '.join(guidance['tests'])}.")
        actions.append(f"Self-care: {', '.join(guidance['self_care'])}.")
    else:
        actions.append(f"Low confidence prediction: {top_label}. Start with self-care and monitor symptoms for 24-48 hours.")
        actions.append(f"Self-care: {', '.join(guidance['self_care'])}.")
        actions.append("Seek medical attention if symptoms worsen or persist.")

    return actions
