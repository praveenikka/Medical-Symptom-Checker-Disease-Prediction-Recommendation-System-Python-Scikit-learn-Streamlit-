import json
from pathlib import Path
from typing import List, Tuple

import joblib
import numpy as np
import pandas as pd

# Paths
ROOT = Path(__file__).resolve().parents[1]
RAW_DATA_PATH = ROOT / "data" / "raw" / "symptoms.csv"
PROCESSED_PATH = ROOT / "data" / "processed" / "dataset.parquet"
ARTIFACTS_DIR = ROOT / "models"
SYMPTOM_VOCAB_PATH = ARTIFACTS_DIR / "symptom_vocab.json"
FEATURE_COLUMNS_PATH = ARTIFACTS_DIR / "feature_columns.json"
LABEL_ENCODER_PATH = ARTIFACTS_DIR / "label_encoder.joblib"

TARGET_COL = "Predicted Disease"
SYMPTOMS_COL = "Symptoms"
AGE_COL = "Age"
GENDER_COL = "Gender"


def _standardize_symptom_token(token: str) -> str:
    token = token.strip().lower()
    # Basic normalization; extend this map for synonyms if desired
    synonyms = {
        "breathlessness": "shortness of breath",
        "runny nose": "rhinorrhea",
    }
    token = synonyms.get(token, token)
    return token


def parse_symptoms(cell: str) -> List[str]:
    if pd.isna(cell) or not str(cell).strip():
        return []
    raw = str(cell).split(",")
    tokens = [_standardize_symptom_token(t) for t in raw]
    # Remove empty tokens
    return [t for t in tokens if t]


def build_symptom_vocab(series: pd.Series) -> List[str]:
    freq = {}
    for cell in series.fillna(""):
        for tok in parse_symptoms(cell):
            freq[tok] = freq.get(tok, 0) + 1
    # Sort by frequency desc, then alphabetically
    vocab = sorted(freq.keys(), key=lambda k: (-freq[k], k))
    return vocab


def encode_features(df: pd.DataFrame, symptom_vocab: List[str]) -> Tuple[pd.DataFrame, pd.Series, List[str]]:
    # Demographics
    df[AGE_COL] = pd.to_numeric(df[AGE_COL], errors="coerce")
    df[AGE_COL] = df[AGE_COL].fillna(df[AGE_COL].median())
    df[GENDER_COL] = df[GENDER_COL].fillna("Unknown").astype(str).str.title()
    gender_dummies = pd.get_dummies(df[GENDER_COL], prefix="gender")

    # Symptoms multi-hot
    symptom_cols = [f"symptom_{s.replace(' ', '_')}" for s in symptom_vocab]
    symptom_mat = np.zeros((len(df), len(symptom_vocab)), dtype=np.int8)
    for i, cell in enumerate(df[SYMPTOMS_COL].fillna("")):
        tokens = set(parse_symptoms(cell))
        for j, s in enumerate(symptom_vocab):
            if s in tokens:
                symptom_mat[i, j] = 1
    symptom_df = pd.DataFrame(symptom_mat, columns=symptom_cols, index=df.index)

    # Combine features
    X = pd.concat([df[[AGE_COL]].reset_index(drop=True), gender_dummies.reset_index(drop=True), symptom_df.reset_index(drop=True)], axis=1)

    # Target
    y = df[TARGET_COL].astype(str)

    # Feature column names (for later prediction)
    feature_columns = list(X.columns)
    return X, y, feature_columns


def main():
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    PROCESSED_PATH.parent.mkdir(parents=True, exist_ok=True)

    if not RAW_DATA_PATH.exists():
        raise FileNotFoundError(f"Raw dataset not found at {RAW_DATA_PATH}")

    df = pd.read_csv(RAW_DATA_PATH)

    # Basic cleaning
    # Keep rows with a label
    df = df.dropna(subset=[TARGET_COL])
    # Strip whitespace in label
    df[TARGET_COL] = df[TARGET_COL].astype(str).str.strip()

    # Build vocab from symptoms
    symptom_vocab = build_symptom_vocab(df[SYMPTOMS_COL])

    # Encode features/labels
    X, y_text, feature_columns = encode_features(df, symptom_vocab)

    # Label encode target
    from sklearn.preprocessing import LabelEncoder

    le = LabelEncoder()
    y = le.fit_transform(y_text)

    # Save processed dataset
    processed = pd.concat([X, pd.Series(y, name="label")], axis=1)
    processed.to_parquet(PROCESSED_PATH, index=False)

    # Save artifacts
    with open(SYMPTOM_VOCAB_PATH, "w", encoding="utf-8") as f:
        json.dump(symptom_vocab, f, ensure_ascii=False, indent=2)
    with open(FEATURE_COLUMNS_PATH, "w", encoding="utf-8") as f:
        json.dump(feature_columns, f, ensure_ascii=False, indent=2)
    joblib.dump(le, LABEL_ENCODER_PATH)

    print("Data prep complete:")
    print(f"- Processed dataset: {PROCESSED_PATH}")
    print(f"- Symptom vocab: {SYMPTOM_VOCAB_PATH}")
    print(f"- Feature columns: {FEATURE_COLUMNS_PATH}")
    print(f"- Label encoder: {LABEL_ENCODER_PATH}")


if __name__ == "__main__":
    main()
