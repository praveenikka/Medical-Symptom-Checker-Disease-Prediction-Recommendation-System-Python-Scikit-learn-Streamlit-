import json
from pathlib import Path
from typing import List

import streamlit as st

from src.predict import predict as predict_fn

ROOT = Path(__file__).resolve().parent
MODELS_DIR = ROOT / "models"
SYMPTOM_VOCAB_PATH = MODELS_DIR / "symptom_vocab.json"


def load_symptom_vocab() -> List[str]:
    with open(SYMPTOM_VOCAB_PATH, "r", encoding="utf-8") as f:
        vocab = json.load(f)
    # Display title case to user
    return [v.title() for v in vocab]


st.set_page_config(page_title="Medical Symptom Checker", page_icon="🩺", layout="centered")

st.title("🩺 Medical Symptom Checker")
st.write("Beginner-friendly demo: predicts likely diseases, shows top-3, and suggests next steps.")

with st.sidebar:
    st.header("Patient Info")
    age = st.number_input("Age", min_value=0, max_value=120, value=30, step=1)
    gender = st.selectbox("Gender", options=["Male", "Female", "Other", "Unknown"], index=1)

# Load symptom options
symptom_options = load_symptom_vocab()
selected_symptoms = st.multiselect("Select your symptoms", options=symptom_options, help="Start typing to filter.")

if st.button("Predict"):
    if len(selected_symptoms) == 0:
        st.warning("Please select at least one symptom.")
    else:
        # Map back to lowercase tokens for the model
        chosen = [s.lower() for s in selected_symptoms]
        label, ranked = predict_fn(age=int(age), gender=gender, symptoms=chosen, top_k=3)

        st.subheader("Prediction")
        st.success(f"Most likely: {label}")

        st.subheader("Top-3 possibilities")
        for name, p in ranked:
            st.write(f"- {name}: {p:.2f}")

        # Recommendations
        try:
            from src.recommender import recommend
            actions = recommend(ranked, age=int(age), gender=gender)
            st.subheader("Recommended next steps")
            for a in actions:
                st.write(f"- {a}")
        except Exception as e:
            st.error(f"Could not generate recommendations: {e}")
